const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS for your frontend domain
app.use(cors({
    origin: '*' // Allow all origins during development
}));

// Serve static files from the parent directory (root of the project)
app.use(express.static('..'));

// Secure endpoint for token prices
app.get('/api/token-prices', async (req, res) => {
    try {
        const tokenIds = req.query.ids;
        if (!tokenIds) {
            return res.status(400).json({ error: 'Token IDs are required' });
        }

        const response = await fetch(
            `https://api.coingecko.com/api/v3/simple/price?ids=${tokenIds}&vs_currencies=usd&include_24hr_change=true`,
            {
                headers: {
                    'x-cg-pro-api-key': process.env.COINGECKO_API_KEY
                }
            }
        );

        if (!response.ok) {
            throw new Error(`CoinGecko API error: ${response.status}`);
        }

        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error fetching token prices:', error);
        res.status(500).json({ error: 'Failed to fetch token prices' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to view the site`);
}); 